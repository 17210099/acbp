﻿<!doctype html public "-//w3c//dtd xhtml 1.0 transitional//en" "http://www.w3.org/tr/xhtml1/dtd/xhtml1-transitional.dtd">
<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="ProgId" content="Excel.Sheet">
  <meta name="Generator" content="Aspose.Cell 21.9">
  <link rel="File-List" href="LAMPIRAN BIAYA PERKARA BARU_files/filelist.xml">
  <link rel="Edit-Time-Data" href="LAMPIRAN BIAYA PERKARA BARU_files/editdata.mso">
  <link rel="OLE-Object-Data" href="LAMPIRAN BIAYA PERKARA BARU_files/oledata.mso">
  <!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Author>IT PN PATI</o:Author>
  <o:LastPrinted>2023-06-03T07:52:45Z</o:LastPrinted>
  <o:Created>2018-10-08T08:22:22Z</o:Created>
  <o:LastSaved>2023-11-05T02:47:35Z</o:LastSaved>
</o:DocumentProperties>
</xml><![endif]-->
  <style>
    <!--table
    {
      mso-displayed-decimal-separator: "\.";
      mso-displayed-thousand-separator: "\,";
    }

    @page {
      mso-header-data: "";
      mso-footer-data: "";
      margin: 0.75in 0.25in 0.75in 0.25in;
      mso-header-margin: 0.3in;
      mso-footer-margin: 0.3in;
      mso-page-orientation: Landscape;
    }

    tr {
      mso-height-source: auto;
      mso-ruby-visibility: none;
    }

    col {
      mso-width-source: auto;
      mso-ruby-visibility: none;
    }

    br {
      mso-data-placement: same-cell;
    }

    ruby {
      ruby-align: left;
    }

    .style0 {
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
      mso-style-name: Normal;
      mso-style-id: 0;
    }

    .font0 {
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
    }

    .font1 {
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
    }

    .font2 {
      color: #000000;
      font-size: 12pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
    }

    .font3 {
      color: #000000;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
    }

    .font4 {
      color: #000000;
      font-size: 14pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
    }

    .font5 {
      color: #000000;
      font-size: 11pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
    }

    .font6 {
      color: #000000;
      font-size: 11pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
    }

    .font7 {
      color: #000000;
      font-size: 11pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
    }

    .font8 {
      color: #000000;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      text-decoration: underline;
      font-family: "Arial", "sans-serif";
    }

    td {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
      mso-ignore: padding;
    }

    .style0 {
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
      mso-style-name: "Normal";
    }

    .style1 {
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .style2 {
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .style3 {
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .style4 {
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .style5 {
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .style6 {
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .style7 {
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .style8 {
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .style9 {
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .style10 {
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .style11 {
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .style12 {
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .style13 {
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .style14 {
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      color: #000000;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x15 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 10pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x16 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 12pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x17 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: top;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 12pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x18 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x19 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 12pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x20 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 14pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x21 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x22 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x23 {
      mso-style-parent: style0;
      mso-number-format: "_\(\0022Rp\0022* \#\,\#\#0_\)\;_\(\0022Rp\0022* \\\(\#\,\#\#0\\\)\;_\(\0022Rp\0022* \0022-\0022_\)\;_\(\@_\)";
      text-align: left;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x24 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: left;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x25 {
      mso-style-parent: style0;
      mso-number-format: "_\(\0022Rp\0022* \#\,\#\#0_\)\;_\(\0022Rp\0022* \\\(\#\,\#\#0\\\)\;_\(\0022Rp\0022* \0022-\0022_\)\;_\(\@_\)";
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x26 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: top;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x27 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x28 {
      mso-style-parent: style0;
      mso-number-format: "_\(\0022Rp\0022* \#\,\#\#0_\)\;_\(\0022Rp\0022* \\\(\#\,\#\#0\\\)\;_\(\0022Rp\0022* \0022-\0022_\)\;_\(\@_\)";
      text-align: left;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x29 {
      mso-style-parent: style0;
      mso-number-format: "_\(\0022Rp\0022* \#\,\#\#0_\)\;_\(\0022Rp\0022* \\\(\#\,\#\#0\\\)\;_\(\0022Rp\0022* \0022-\0022_\)\;_\(\@_\)";
      text-align: left;
      vertical-align: top;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x30 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: justify;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x31 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: justify;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x32 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: justify;
      vertical-align: middle;
      white-space: normal;
      word-wrap: break-word;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x33 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x34 {
      mso-style-parent: style0;
      mso-number-format: "_\(\0022Rp\0022* \#\,\#\#0_\)\;_\(\0022Rp\0022* \\\(\#\,\#\#0\\\)\;_\(\0022Rp\0022* \0022-\0022_\)\;_\(\@_\)";
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x35 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x36 {
      mso-style-parent: style0;
      mso-number-format: "_\(\0022Rp\0022* \#\,\#\#0_\)\;_\(\0022Rp\0022* \\\(\#\,\#\#0\\\)\;_\(\0022Rp\0022* \0022-\0022_\)\;_\(\@_\)";
      text-align: left;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x37 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: none;
      border-bottom: none;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x38 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x39 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x40 {
      mso-style-parent: style0;
      mso-number-format: "_\(\0022Rp\0022* \#\,\#\#0_\)\;_\(\0022Rp\0022* \\\(\#\,\#\#0\\\)\;_\(\0022Rp\0022* \0022-\0022_\)\;_\(\@_\)";
      text-align: left;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: none;
      border-bottom: none;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x41 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: none;
      border-bottom: 2px solid windowtext;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x42 {
      mso-style-parent: style0;
      mso-number-format: "_\(\0022Rp\0022* \#\,\#\#0_\)\;_\(\0022Rp\0022* \\\(\#\,\#\#0\\\)\;_\(\0022Rp\0022* \0022-\0022_\)\;_\(\@_\)";
      text-align: left;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: none;
      border-bottom: none;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x43 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: left;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x44 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: left;
      vertical-align: middle;
      white-space: normal;
      word-wrap: break-word;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x45 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: top;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x46 {
      mso-style-parent: style0;
      mso-number-format: "_\(\0022Rp\0022* \#\,\#\#0_\)\;_\(\0022Rp\0022* \\\(\#\,\#\#0\\\)\;_\(\0022Rp\0022* \0022-\0022_\)\;_\(\@_\)";
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x47 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: left;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 11pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x48 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 11pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x49 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 11pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x50 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: left;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      color: #000000;
      font-size: 11pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: none;
      border-bottom: none;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x51 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: left;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      color: #000000;
      font-size: 11pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: none;
      border-bottom: none;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x52 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: left;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 11pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: none;
      border-bottom: none;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x53 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: left;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 11pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: none;
      border-bottom: none;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x54 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: left;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 11pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: 2px solid windowtext;
      border-bottom: none;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x55 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 11pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: 2px solid windowtext;
      border-bottom: none;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x56 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 11pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: none;
      border-bottom: none;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x57 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: left;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 11pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: none;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x58 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: left;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 11pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: none;
      border-bottom: 2px solid windowtext;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x59 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 12pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: none;
      border-bottom: 2px solid windowtext;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x60 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 12pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x61 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x62 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 12pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x63 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x64 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 14pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: none;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x65 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 14pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: none;
      border-bottom: 2px solid windowtext;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x66 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x67 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 11pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x68 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 12pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: none;
      border-bottom: none;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x69 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 12pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: none;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x70 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 12pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: 2px solid windowtext;
      border-bottom: none;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x71 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 11pt;
      font-weight: 400;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: none;
      border-right: 2px solid windowtext;
      border-bottom: none;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x72 {
      mso-style-parent: style0;
      mso-number-format: "_\(\0022Rp\0022* \#\,\#\#0_\)\;_\(\0022Rp\0022* \\\(\#\,\#\#0\\\)\;_\(\0022Rp\0022* \0022-\0022_\)\;_\(\@_\)";
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x73 {
      mso-style-parent: style0;
      mso-number-format: "_\(\0022Rp\0022* \#\,\#\#0_\)\;_\(\0022Rp\0022* \\\(\#\,\#\#0\\\)\;_\(\0022Rp\0022* \0022-\0022_\)\;_\(\@_\)";
      text-align: general;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: none;
      border-bottom: none;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x74 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: justify;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x75 {
      mso-style-parent: style0;
      mso-number-format: "_\(\0022Rp\0022* \#\,\#\#0_\)\;_\(\0022Rp\0022* \\\(\#\,\#\#0\\\)\;_\(\0022Rp\0022* \0022-\0022_\)\;_\(\@_\)";
      text-align: left;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x76 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: left;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x77 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 1px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x78 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 1px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 1px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x79 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 1px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x80 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: none;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x81 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: none;
      border-bottom: 2px solid windowtext;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x82 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x83 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: none;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x84 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: none;
      border-bottom: 2px solid windowtext;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x85 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: bottom;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: none;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x86 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: middle;
      white-space: nowrap;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: none;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x87 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: middle;
      white-space: normal;
      word-wrap: break-word;
      background: #FFFFFF;
      mso-pattern: auto none;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      border-top: 2px solid windowtext;
      border-right: 2px solid windowtext;
      border-bottom: 2px solid windowtext;
      border-left: 2px solid windowtext;
      mso-diagonal-down: none;
      mso-diagonal-up: none;
      mso-protection: locked visible;
    }

    .x88 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      text-decoration: underline;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x89 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }

    .x90 {
      mso-style-parent: style0;
      mso-number-format: General;
      text-align: center;
      vertical-align: bottom;
      white-space: nowrap;
      background: auto;
      mso-pattern: auto;
      font-size: 12pt;
      font-weight: 700;
      font-style: normal;
      font-family: "Arial", "sans-serif";
      mso-protection: locked visible;
    }
    -->
  </style>
  <!--[if gte mso 9]><xml>
 <x:ExcelWorkbook>
  <x:ExcelWorksheets>
   <x:ExcelWorksheet>
    <x:Name>CETAK BANNER</x:Name>
<x:WorksheetOptions>
 <x:StandardWidth>4704</x:StandardWidth>
 <x:Print>
  <x:ValidPrinterInfo/>
  <x:PaperSizeIndex>5</x:PaperSizeIndex>
  <x:Scale>80</x:Scale>
  <x:HorizontalResolution>600</x:HorizontalResolution>
  <x:VerticalResolution>600</x:VerticalResolution>
 </x:Print>
 <x:Selected/>
</x:WorksheetOptions>
   </x:ExcelWorksheet>
  </x:ExcelWorksheets>
  <x:WindowHeight>11760</x:WindowHeight>
  <x:WindowWidth>20730</x:WindowWidth>
  <x:WindowTopX>0</x:WindowTopX>
  <x:WindowTopY>0</x:WindowTopY>
  <x:RefModeR1C1/>
  <x:TabRatio>600</x:TabRatio>
  <x:ActiveSheet>0</x:ActiveSheet>
 </x:ExcelWorkbook>
</xml><![endif]-->
</head>

<body link='blue' vlink='purple' class='x16'>

  <table border='0' cellpadding='0' cellspacing='0' width='1164' style='border-collapse: 
 collapse;table-layout:fixed;width:873pt'>
    <col class='x16' width='30' style='mso-width-source:userset;background:none;width:22.5pt'>
    <col class='x16' width='393' style='mso-width-source:userset;background:none;width:294.75pt'>
    <col class='x16' width='120' style='mso-width-source:userset;background:none;width:90pt'>
    <col class='x16' width='123' style='mso-width-source:userset;background:none;width:92.25pt'>
    <col class='x16' width='128' style='mso-width-source:userset;background:none;width:96pt'>
    <col class='x16' width='124' style='mso-width-source:userset;background:none;width:93pt'>
    <col class='x16' width='121' style='mso-width-source:userset;background:none;width:90.75pt'>
    <col class='x16' width='125' style='mso-width-source:userset;background:none;width:93.75pt'>
    <tr height='20' style='mso-height-source:userset;height:15pt' id='r0'>
      <td height='20' class='x16' width='30' style='height:15pt;width:22.5pt;'></td>
      <td class='x16' width='393' style='width:294.75pt;'></td>
      <td class='x16' width='120' style='width:90pt;'></td>
      <td colspan='2' class='x17' width='251' style='mso-ignore:colspan;'>Daftar Lampiran II</td>
      <td class='x16' width='124' style='width:93pt;'></td>
      <td class='x16' width='121' style='width:90.75pt;'></td>
      <td class='x16' width='125' style='width:93.75pt;'></td>
    </tr>
    <tr height='20' style='mso-height-source:userset;height:15pt' id='r1'>
      <td height='20' class='x16' style='height:15pt'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='20' style='mso-height-source:userset;height:15pt' id='r2'>
      <td height='20' class='x16' style='height:15pt;'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td colspan='4' class='x17' style='mso-ignore:colspan;'>Surat Keputusan Ketua Pengadilan Negeri Tondano Kelas IB</td>
      <td class='x16'></td>
    </tr>
    <tr height='20' style='mso-height-source:userset;height:15pt' id='r3'>
      <td height='20' class='x16' style='height:15pt;'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td colspan='3' class='x17' style='mso-ignore:colspan;'>Nomor<span style='mso-spacerun:yes;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>:<span style='mso-spacerun:yes;'>&nbsp;&nbsp;</span>W19-U2/<span style='mso-spacerun:yes;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>/HT/V/2023</td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='20' style='mso-height-source:userset;height:15pt' id='r4'>
      <td height='20' class='x16' style='height:15pt'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='29' class='x19' style='mso-height-source:userset;height:21.95pt' id='r5'>
      <td colspan='2' height='29' class='x20' style='mso-ignore:colspan;height:21.95pt;'>TINGKAT PERTAMA</td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x19'></td>
      <td class='x19'></td>
    </tr>
    <tr height='29' class='x19' style='mso-height-source:userset;height:21.95pt' id='r6'>
      <td colspan='3' height='27' class='x20' style='mso-ignore:colspan;height:20.45pt;'>PERKARA GUGATAN / BANTAHAN / PERLAWANAN</td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x19'></td>
      <td class='x19'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r7'>
      <td rowspan='2' height='42' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.9pt;'>No.</td>
      <td rowspan='2' height='42' class='x80' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.9pt;'>Uraian</td>
      <td colspan='6' class='x77' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;'>Biaya</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r8'>
      <td class='x61'>Radius 1</td>
      <td class='x61'>Radius II</td>
      <td class='x61'>Radius III</td>
      <td class='x61'>Radius IV</td>
      <td class='x61'>Radius V</td>
      <td class='x61'>Radius VI</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r9'>
      <td height='19' class='x22' style='height:14.45pt;'>1</td>
      <td class='x24'>Pendaftaran</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r10'>
      <td height='19' class='x22' style='height:14.45pt;'>2</td>
      <td class='x24'>Biaya Proses/ATK</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r11'>
      <td height='19' class='x22' style='height:14.45pt;'>3</td>
      <td class='x24'>PNBP Surat Kuasa</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r12'>
      <td height='19' class='x22' style='height:14.45pt;'>4</td>
      <td class='x24'>Panggilan Penggugat 2x</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
      <td class='x23' x:num="400000"> Rp 400,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="700000"> Rp 700,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r13'>
      <td height='19' class='x22' style='height:14.45pt;'>5</td>
      <td class='x24'>Panggilan Tergugat 3x</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="450000"> Rp 450,000</td>
      <td class='x23' x:num="525000"> Rp 525,000</td>
      <td class='x23' x:num="600000"> Rp 600,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="1050000"> Rp 1,050,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r14'>
      <td height='19' class='x22' style='height:14.45pt;'>6</td>
      <td class='x24'>Panggilan Mediasi P 2x</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
      <td class='x23' x:num="400000"> Rp 400,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="700000"> Rp 700,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r15'>
      <td height='19' class='x22' style='height:14.45pt;'>7</td>
      <td class='x24'>Panggilan Mediasi T 2x</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
      <td class='x23' x:num="400000"> Rp 400,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="700000"> Rp 700,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r16'>
      <td height='19' class='x22' style='height:14.45pt;'>8</td>
      <td class='x24'>Materai</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r17'>
      <td height='19' class='x22' style='height:14.45pt;'>9</td>
      <td class='x24'>Redaksi&nbsp;</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r18'>
      <td height='19' class='x22' style='height:14.45pt;'>10</td>
      <td class='x24'>Pemberitahuan Putusan Penggugat dan Tergugat</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
      <td class='x23' x:num="400000"> Rp 400,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="700000"> Rp 700,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r19'>
      <td height='19' class='x22' style='height:14.45pt;'>11</td>
      <td class='x24'>PNBP Panggilan dan Pemberitahuan 9x</td>
      <td class='x23' x:num="90000"> Rp 90,000</td>
      <td class='x23' x:num="90000"> Rp 90,000</td>
      <td class='x23' x:num="90000"> Rp 90,000</td>
      <td class='x23' x:num="90000"> Rp 90,000</td>
      <td class='x23' x:num="90000"> Rp 90,000</td>
      <td class='x23' x:num="90000"> Rp 90,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r20'>
      <td height='19' class='x22' style='height:14.45pt;'>12</td>
      <td class='x24'>PNBP Pencabutan</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r21'>
      <td colspan='2' height='19' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:14.45pt;'>JUMLAH</td>
      <td class='x25' align='right' x:num="1310000" x:fmla="=SUM(C10:C21)" style='text-align:right;'> Rp 1,310,000</td>
      <td class='x25' align='right' x:num="1860000" x:fmla="=SUM(D10:D21)" style='text-align:right;'> Rp 1,860,000</td>
      <td class='x25' align='right' x:num="2135000" x:fmla="=SUM(E10:E21)" style='text-align:right;'> Rp 2,135,000</td>
      <td class='x25' align='right' x:num="2410000" x:fmla="=SUM(F10:F21)" style='text-align:right;'> Rp 2,410,000</td>
      <td class='x25' align='right' x:num="2960000" x:fmla="=SUM(G10:G21)" style='text-align:right;'> Rp 2,960,000</td>
      <td class='x25' align='right' x:num="4060000" x:fmla="=SUM(H10:H21)" style='text-align:right;'> Rp 4,060,000</td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r22'>
      <td height='19' class='x26' style='height:14.25pt;'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='29' class='x19' style='mso-height-source:userset;height:21.95pt' id='r23'>
      <td colspan='2' height='27' class='x20' style='mso-ignore:colspan;height:20.45pt;'>PERKARA PERMOHONAN</td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x19'></td>
      <td class='x19'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r24'>
      <td rowspan='2' height='42' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.9pt;'>No.</td>
      <td rowspan='2' height='42' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.9pt;'>Uraian</td>
      <td colspan='6' class='x80' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;'>Biaya</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r25'>
      <td class='x22'>Radius 1</td>
      <td class='x22'>Radius II</td>
      <td class='x22'>Radius III</td>
      <td class='x22'>Radius IV</td>
      <td class='x61'>Radius V</td>
      <td class='x61'>Radius VI</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r26'>
      <td height='19' class='x22' style='height:14.45pt;'>1</td>
      <td class='x24'>Pendaftaran</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r27'>
      <td height='19' class='x22' style='height:14.45pt;'>2</td>
      <td class='x24'>Biaya Proses/ATK</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r28'>
      <td height='19' class='x22' style='height:14.45pt;'>3</td>
      <td class='x24'>PNBP Surat Kuasa</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r29'>
      <td height='19' class='x22' style='height:14.45pt;'>4</td>
      <td class='x24'>Panggilan 2x</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
      <td class='x23' x:num="400000"> Rp 400,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="700000"> Rp 700,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r30'>
      <td height='19' class='x22' style='height:14.45pt;'>5</td>
      <td class='x24'>Materai&nbsp;</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r31'>
      <td height='19' class='x22' style='height:14.45pt;'>6</td>
      <td class='x24'>Redaksi&nbsp;</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r32'>
      <td height='19' class='x22' style='height:14.45pt;'>7</td>
      <td class='x24'>Biaya Pemberitahuan Penetapan</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="175000"> Rp 175,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="250000"> Rp 250,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r33'>
      <td height='19' class='x22' style='height:14.45pt;'>8</td>
      <td class='x24'>PNBP Panggilan dan Pemberitahuan 2x</td>
      <td class='x23' x:num="20000"> Rp 20,000</td>
      <td class='x23' x:num="20000"> Rp 20,000</td>
      <td class='x23' x:num="20000"> Rp 20,000</td>
      <td class='x23' x:num="20000"> Rp 20,000</td>
      <td class='x23' x:num="20000"> Rp 20,000</td>
      <td class='x23' x:num="20000"> Rp 20,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r34'>
      <td height='19' class='x22' style='height:14.45pt;'>9</td>
      <td class='x24'>PNBP Pencabutan</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r35'>
      <td colspan='2' height='18' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:13.5pt;'>JUMLAH&nbsp;</td>
      <td class='x23' x:num="440000" x:fmla="=SUM(C27:C35)"> Rp 440,000</td>
      <td class='x23' x:num="590000" x:fmla="=SUM(D27:D35)"> Rp 590,000</td>
      <td class='x23' x:num="665000" x:fmla="=SUM(E27:E35)"> Rp 665,000</td>
      <td class='x23' x:num="740000" x:fmla="=SUM(F27:F35)"> Rp 740,000</td>
      <td class='x23' x:num="890000" x:fmla="=SUM(G27:G35)"> Rp 890,000</td>
      <td class='x23' x:num="1190000" x:fmla="=SUM(H27:H35)"> Rp 1,190,000</td>
    </tr>
    <tr height='29' class='x19' style='mso-height-source:userset;height:21.95pt' id='r36'>
      <td height='27' class='x27' style='height:20.45pt;'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x19'></td>
      <td class='x19'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r37'>
      <td colspan='2' height='21' class='x20' style='mso-ignore:colspan;height:15.95pt;'>PERKARA GUGATAN SEDERHANA</td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r38'>
      <td rowspan='2' height='42' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.9pt;'>No.</td>
      <td rowspan='2' height='42' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.9pt;'>Uraian</td>
      <td colspan='6' class='x83' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;'>Biaya</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r39'>
      <td class='x33'>Radius 1</td>
      <td class='x33'>Radius II</td>
      <td class='x33'>Radius III</td>
      <td class='x33'>Radius IV</td>
      <td class='x61'>Radius V</td>
      <td class='x61'>Radius VI</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r40'>
      <td height='19' class='x22' style='height:14.45pt;'>1</td>
      <td class='x43'>Pendaftaran</td>
      <td class='x28' x:num="30000"> Rp 30,000</td>
      <td class='x28' x:num="30000"> Rp 30,000</td>
      <td class='x28' x:num="30000"> Rp 30,000</td>
      <td class='x28' x:num="30000"> Rp 30,000</td>
      <td class='x28' x:num="30000"> Rp 30,000</td>
      <td class='x28' x:num="30000"> Rp 30,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r41'>
      <td height='19' class='x22' style='height:14.45pt;'>2</td>
      <td class='x43'>Biaya Proses/ATK</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r42'>
      <td height='19' class='x22' style='height:14.45pt;'>3</td>
      <td class='x24'>PNBP Surat Kuasa</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r43'>
      <td height='19' class='x22' style='height:14.45pt;'>4</td>
      <td class='x43'>Panggilan Penggugat 2x</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
      <td class='x23' x:num="400000"> Rp 400,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="700000"> Rp 700,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r44'>
      <td height='19' class='x22' style='height:14.45pt;'>5</td>
      <td class='x43'>Panggilan Tergugat 3x</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="450000"> Rp 450,000</td>
      <td class='x23' x:num="525000"> Rp 525,000</td>
      <td class='x23' x:num="600000"> Rp 600,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="1050000"> Rp 1,050,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r45'>
      <td height='19' class='x22' style='height:14.45pt;'>6</td>
      <td class='x43'>Materai</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r46'>
      <td height='19' class='x22' style='height:14.45pt;'>7</td>
      <td class='x43'>Redaksi&nbsp;</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r47'>
      <td height='19' class='x22' style='height:14.45pt;'>8</td>
      <td class='x43'>Pemberitahuan Putusan Penggugat dan Tergugat</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
      <td class='x23' x:num="400000"> Rp 400,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="700000"> Rp 700,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r48'>
      <td height='19' class='x22' style='height:14.45pt;'>9</td>
      <td class='x43'>PNBP Panggilan dan Pemberitahuan 4x</td>
      <td class='x28' x:num="40000"> Rp 40,000</td>
      <td class='x28' x:num="40000"> Rp 40,000</td>
      <td class='x28' x:num="40000"> Rp 40,000</td>
      <td class='x28' x:num="40000"> Rp 40,000</td>
      <td class='x28' x:num="40000"> Rp 40,000</td>
      <td class='x28' x:num="40000"> Rp 40,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r49'>
      <td height='19' class='x22' style='height:14.45pt;'>10</td>
      <td class='x43'>PNBP Pencabutan</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' class='x19' style='mso-height-source:userset;height:17.25pt' id='r50'>
      <td colspan='2' height='19' class='x45' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:14.25pt;'>JUMLAH</td>
      <td class='x29' x:num="860000" x:fmla="=SUM(C41:C50)"> Rp 860,000</td>
      <td class='x29' x:num="1210000" x:fmla="=SUM(D41:D50)"> Rp 1,210,000</td>
      <td class='x29' x:num="1385000" x:fmla="=SUM(E41:E50)"> Rp 1,385,000</td>
      <td class='x29' x:num="1560000" x:fmla="=SUM(F41:F50)"> Rp 1,560,000</td>
      <td class='x29' x:num="1910000" x:fmla="=SUM(G41:G50)"> Rp 1,910,000</td>
      <td class='x29' x:num="2610000" x:fmla="=SUM(H41:H50)"> Rp 2,610,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r51'>
      <td height='21' class='x27' style='height:15.95pt;'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r52'>
      <td colspan='4' height='21' class='x20' style='mso-ignore:colspan;height:15.95pt;'>PERKARA KEBERATAN TERHADAP GUGATAN SEDERHANA</td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r53'>
      <td rowspan='2' height='42' class='x87' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.9pt;'>No.</td>
      <td rowspan='2' height='42' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.9pt;'>Uraian</td>
      <td colspan='6' class='x80' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;'>Biaya</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r54'>
      <td class='x61'>Radius I</td>
      <td class='x61'>Radius II</td>
      <td class='x61'>Radius III</td>
      <td class='x61'>Radius IV</td>
      <td class='x61'>Radius V</td>
      <td class='x61'>Radius VI</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r55'>
      <td height='19' class='x22' style='height:14.45pt;'>1</td>
      <td class='x24'>Pemberitahuan Pernyataan Keberatan</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="175000"> Rp 175,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="250000"> Rp 250,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r56'>
      <td height='19' class='x22' style='height:14.45pt;'>2</td>
      <td class='x44'>Pemberitahuan Memori Keberatan</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="175000"> Rp 175,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="250000"> Rp 250,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r57'>
      <td height='19' class='x22' style='height:14.45pt;'>3</td>
      <td class='x44'>Pemberitahuan Kontra Memori Keberatan</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="175000"> Rp 175,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="250000"> Rp 250,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r58'>
      <td height='19' class='x22' style='height:14.45pt;'>4</td>
      <td class='x24'>Materai</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r59'>
      <td height='19' class='x22' style='height:14.45pt;'>5</td>
      <td class='x24'>Redaksi&nbsp;</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r60'>
      <td height='19' class='x22' style='height:14.45pt;'>6</td>
      <td class='x44'>Pemberitahuan Isi Putusan Keberatan P dan T</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
      <td class='x23' x:num="400000"> Rp 400,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="400000"> Rp 400,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r61'>
      <td height='18' class='x22' style='height:13.5pt;'>7</td>
      <td class='x44'>PNBP Relaas-relaas 5x</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
    </tr>
    <tr height='26' class='x19' style='mso-height-source:userset;height:19.5pt' id='r62'>
      <td colspan='2' height='22' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:16.5pt;'>JUMLAH</td>
      <td class='x23' x:num="570000" x:fmla="=SUM(C56:C62)"> Rp 570,000</td>
      <td class='x23' x:num="820000" x:fmla="=SUM(D56:D62)"> Rp 820,000</td>
      <td class='x23' x:num="945000" x:fmla="=SUM(E56:E62)"> Rp 945,000</td>
      <td class='x23' x:num="1070000" x:fmla="=SUM(F56:F62)"> Rp 1,070,000</td>
      <td class='x23' x:num="1320000" x:fmla="=SUM(G56:G62)"> Rp 1,320,000</td>
      <td class='x23' x:num="1520000" x:fmla="=SUM(H56:H62)"> Rp 1,520,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r63'>
      <td height='21' class='x27' style='height:15.95pt;'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r64'>
      <td colspan='3' height='21' class='x20' style='mso-ignore:colspan;height:15.95pt;'>BIAYA PANGGILAN MELALUI IKLAN/RADIO/PENGUMUMAN</td>
      <td class='x39'></td>
      <td class='x39'></td>
      <td class='x21'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r65'>
      <td height='19' class='x22' style='height:14.45pt;'>No.</td>
      <td class='x22'>Uraian</td>
      <td class='x33'>Biaya</td>
      <td class='x37'></td>
      <td class='x38'></td>
      <td class='x38'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r66'>
      <td height='18' class='x22' style='height:13.5pt;'>1</td>
      <td class='x31'>Biaya Panggilan Melalui Iklan (Koran) untuk 1x Iklan</td>
      <td class='x23' x:num="2000000"> Rp 2,000,000</td>
      <td class='x40'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r67'>
      <td height='19' class='x22' style='height:14.45pt;'>2</td>
      <td class='x31'>PNBP Relaas</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x40'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r68'>
      <td height='18' class='x22' style='height:13.5pt;'>3</td>
      <td class='x31'>Biaya Panggilan Melalui Radio untuk 1x Siaran</td>
      <td class='x23' x:num="175000"> Rp 175,000</td>
      <td class='x40'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r69'>
      <td height='18' class='x22' style='height:13.5pt;'>4</td>
      <td class='x31'>PNBP Relaas</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x40'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r70'>
      <td height='18' class='x22' style='height:13.5pt;'>5</td>
      <td class='x44'>Biaya Panggilan Melalui Pengumuman</td>
      <td class='x23' x:num="175000"> Rp 175,000</td>
      <td class='x40'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='29' class='x19' style='mso-height-source:userset;height:21.95pt' id='r71'>
      <td height='25' class='x22' style='height:18.95pt;'>6</td>
      <td class='x31'>PNBP Relaas</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x40'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x19'></td>
      <td class='x19'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r72'>
      <td height='19' class='x35' style='height:14.25pt;'></td>
      <td class='x35'></td>
      <td class='x42'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='24' style='mso-height-source:userset;height:18pt' id='r73'>
      <td colspan='2' height='24' class='x20' style='mso-ignore:colspan;height:18pt;'>TINGKAT BANDING</td>
      <td class='x39'></td>
      <td class='x39'></td>
      <td class='x39'></td>
      <td class='x21'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r74'>
      <td height='21' class='x20' style='height:15.95pt;'>PERMOHONAN BANDING</td>
      <td class='x41'></td>
      <td class='x39'></td>
      <td class='x39'></td>
      <td class='x39'></td>
      <td class='x39'></td>
      <td class='x62'></td>
      <td class='x62'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r75'>
      <td rowspan='2' height='42' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.9pt;'>No.</td>
      <td rowspan='2' height='42' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.9pt;'>Uraian</td>
      <td colspan='6' class='x83' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;'>Biaya</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r76'>
      <td class='x33'>Radius 1</td>
      <td class='x33'>Radius II</td>
      <td class='x33'>Radius III</td>
      <td class='x33'>Radius IV</td>
      <td class='x61'>Radius V</td>
      <td class='x61'>Radius VI</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r77'>
      <td height='19' class='x22' style='height:14.45pt;'>1</td>
      <td class='x31'>Pendaftaran</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r78'>
      <td height='19' class='x22' style='height:14.45pt;'>2</td>
      <td class='x31'>Biaya Proses/ATK</td>
      <td class='x23' x:num="140000"> Rp 140,000</td>
      <td class='x23' x:num="140000"> Rp 140,000</td>
      <td class='x23' x:num="140000"> Rp 140,000</td>
      <td class='x23' x:num="140000"> Rp 140,000</td>
      <td class='x23' x:num="140000"> Rp 140,000</td>
      <td class='x23' x:num="140000"> Rp 140,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r79'>
      <td height='19' class='x22' style='height:14.45pt;'>3</td>
      <td class='x31'>PNBP Akta Banding</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r80'>
      <td height='18' class='x22' style='height:13.5pt;'>4</td>
      <td class='x31'>Pemberitahuan Banding</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="175000"> Rp 175,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="250000"> Rp 250,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r81'>
      <td height='18' class='x22' style='height:13.5pt;'>5</td>
      <td class='x44'>Penyerahan Memori Banding</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="175000"> Rp 175,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="250000"> Rp 250,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r82'>
      <td height='18' class='x22' style='height:13.5pt;'>6</td>
      <td class='x44'>Penyerahan Kontra Banding</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="175000"> Rp 175,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="250000"> Rp 250,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r83'>
      <td height='18' class='x22' style='height:13.5pt;'>7</td>
      <td class='x31'>Pemberitahuan Inzage P dan T</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
      <td class='x23' x:num="400000"> Rp 400,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="700000"> Rp 700,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r84'>
      <td height='18' class='x22' style='height:13.5pt;'>8</td>
      <td class='x32'>Biaya Proses Pengadilan Tinggi</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r85'>
      <td height='18' class='x22' style='height:13.5pt;'>9</td>
      <td class='x32'>Pemberitahuan Putusan P dan T</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
      <td class='x23' x:num="400000"> Rp 400,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="700000"> Rp 700,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r86'>
      <td height='18' class='x22' style='height:13.5pt;'>10</td>
      <td class='x32'>PNBP Relaas 7x</td>
      <td class='x23' x:num="70000"> Rp 70,000</td>
      <td class='x23' x:num="70000"> Rp 70,000</td>
      <td class='x23' x:num="70000"> Rp 70,000</td>
      <td class='x23' x:num="70000"> Rp 70,000</td>
      <td class='x23' x:num="70000"> Rp 70,000</td>
      <td class='x23' x:num="70000"> Rp 70,000</td>
    </tr>
    <tr height='29' class='x19' style='mso-height-source:userset;height:21.95pt' id='r87'>
      <td colspan='2' height='25' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:18.95pt;'>JUMLAH</td>
      <td class='x23' x:num="1120000" x:fmla="=SUM(C78:C87)"> Rp 1,120,000</td>
      <td class='x23' x:num="1470000" x:fmla="=SUM(D78:D87)"> Rp 1,470,000</td>
      <td class='x23' x:num="1645000" x:fmla="=SUM(E78:E87)"> Rp 1,645,000</td>
      <td class='x23' x:num="1820000" x:fmla="=SUM(F78:F87)"> Rp 1,820,000</td>
      <td class='x23' x:num="2170000" x:fmla="=SUM(G78:G87)"> Rp 2,170,000</td>
      <td class='x23' x:num="2870000" x:fmla="=SUM(H78:H87)"> Rp 2,870,000</td>
    </tr>
    <tr height='29' class='x19' style='mso-height-source:userset;height:21.95pt' id='r88'>
      <td height='27' class='x35' style='height:20.45pt;'></td>
      <td class='x35'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x19'></td>
      <td class='x19'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r89'>
      <td colspan='2' height='23' class='x20' style='mso-ignore:colspan;height:17.45pt;'>TINGKAT KASASI</td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r90'>
      <td colspan='2' height='21' class='x20' style='mso-ignore:colspan;height:15.95pt;'>PERMOHONAN KASASI</td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r91'>
      <td rowspan='2' height='42' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.9pt;'>No.</td>
      <td rowspan='2' height='42' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.9pt;'>Uraian</td>
      <td colspan='6' class='x83' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;'>Biaya</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r92'>
      <td class='x33'>Radius 1</td>
      <td class='x33'>Radius II</td>
      <td class='x33'>Radius III</td>
      <td class='x33'>Radius IV</td>
      <td class='x61'>Radius V</td>
      <td class='x61'>Radius VI</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r93'>
      <td height='19' class='x22' style='height:14.45pt;'>1</td>
      <td class='x31'>Pendaftaran</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r94'>
      <td height='19' class='x22' style='height:14.45pt;'>2</td>
      <td class='x31'>Biaya Proses/ATK</td>
      <td class='x23' x:num="210000"> Rp 210,000</td>
      <td class='x23' x:num="210000"> Rp 210,000</td>
      <td class='x23' x:num="210000"> Rp 210,000</td>
      <td class='x23' x:num="210000"> Rp 210,000</td>
      <td class='x23' x:num="210000"> Rp 210,000</td>
      <td class='x23' x:num="210000"> Rp 210,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r95'>
      <td height='18' class='x22' style='height:13.5pt;'>3</td>
      <td class='x31'>PNBP Akta Kasasi</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r96'>
      <td height='18' class='x22' style='height:13.5pt;'>4</td>
      <td class='x31'>Pemberitahuan Kasasi</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="175000"> Rp 175,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="250000"> Rp 250,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r97'>
      <td height='18' class='x22' style='height:13.5pt;'>5</td>
      <td class='x44'>Penyerahan Memori Kasasi</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="175000"> Rp 175,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="250000"> Rp 250,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r98'>
      <td height='18' class='x22' style='height:13.5pt;'>6</td>
      <td class='x44'>Penyerahan Kontra Kasasi</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="175000"> Rp 175,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="250000"> Rp 250,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r99'>
      <td height='18' class='x22' style='height:13.5pt;'>7</td>
      <td class='x31'>Pemberitahuan Inzage P dan T</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
      <td class='x23' x:num="400000"> Rp 400,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="700000"> Rp 700,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r100'>
      <td height='18' class='x22' style='height:13.5pt;'>8</td>
      <td class='x31'>Biaya Pengiriman ke MA</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r101'>
      <td height='18' class='x22' style='height:13.5pt;'>9</td>
      <td class='x32'>Pemberitahuan Putusan 2 orang P dan T</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
      <td class='x23' x:num="400000"> Rp 400,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="700000"> Rp 700,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r102'>
      <td height='18' class='x22' style='height:13.5pt;'>10</td>
      <td class='x32'>PNBP Relaas / Pemberitahuan 5x</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
    </tr>
    <tr height='28' class='x19' style='mso-height-source:userset;height:21pt' id='r103'>
      <td colspan='2' height='24' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:18pt;'>JUMLAH</td>
      <td class='x23' x:num="1520000" x:fmla="=SUM(C94:C103)"> Rp 1,520,000</td>
      <td class='x23' x:num="1870000" x:fmla="=SUM(D94:D103)"> Rp 1,870,000</td>
      <td class='x23' x:num="2045000" x:fmla="=SUM(E94:E103)"> Rp 2,045,000</td>
      <td class='x23' x:num="2220000" x:fmla="=SUM(F94:F103)"> Rp 2,220,000</td>
      <td class='x23' x:num="2570000" x:fmla="=SUM(G94:G103)"> Rp 2,570,000</td>
      <td class='x23' x:num="3270000" x:fmla="=SUM(H94:H103)"> Rp 3,270,000</td>
    </tr>
    <tr height='28' class='x19' style='mso-height-source:userset;height:21pt' id='r104'>
      <td height='26' class='x35' style='height:19.5pt;'></td>
      <td class='x35'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
    </tr>
    <tr height='24' style='mso-height-source:userset;height:18pt' id='r105'>
      <td colspan='2' height='24' class='x20' style='mso-ignore:colspan;height:18pt;'>TINGKAT PENINJAUAN KEMBALI</td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='25' style='mso-height-source:userset;height:18.75pt' id='r106'>
      <td colspan='2' height='23' class='x20' style='mso-ignore:colspan;height:17.25pt;'>PERMOHONAN PENINJAUAN KEMBALI</td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r107'>
      <td rowspan='2' height='40' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:30pt;'>No.</td>
      <td rowspan='2' height='40' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:30pt;'>Uraian</td>
      <td colspan='6' class='x83' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;'>Biaya</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r108'>
      <td class='x33'>Radius 1</td>
      <td class='x33'>Radius II</td>
      <td class='x33'>Radius III</td>
      <td class='x33'>Radius IV</td>
      <td class='x61'>Radius V</td>
      <td class='x61'>Radius VI</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r109'>
      <td height='18' class='x22' style='height:13.5pt;'>1</td>
      <td class='x24'>Pendaftaran</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r110'>
      <td height='18' class='x22' style='height:13.5pt;'>2.</td>
      <td class='x24'>Biaya Proses/ATK</td>
      <td class='x23' x:num="210000"> Rp 210,000</td>
      <td class='x23' x:num="210000"> Rp 210,000</td>
      <td class='x23' x:num="210000"> Rp 210,000</td>
      <td class='x23' x:num="210000"> Rp 210,000</td>
      <td class='x23' x:num="210000"> Rp 210,000</td>
      <td class='x23' x:num="210000"> Rp 210,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r111'>
      <td height='18' class='x22' style='height:13.5pt;'>3.</td>
      <td class='x24'>PNBP Akta PK</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r112'>
      <td height='18' class='x22' style='height:13.5pt;'>4.</td>
      <td class='x24'>PNBP Penyumpahan Novum (bukti baru) PK</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r113'>
      <td height='18' class='x22' style='height:13.5pt;'>5.</td>
      <td class='x24'>Biaya Peninjauan Kembali</td>
      <td class='x23' x:num="2500000"> Rp 2,500,000</td>
      <td class='x23' x:num="2500000"> Rp 2,500,000</td>
      <td class='x23' x:num="2500000"> Rp 2,500,000</td>
      <td class='x23' x:num="2500000"> Rp 2,500,000</td>
      <td class='x23' x:num="2500000"> Rp 2,500,000</td>
      <td class='x23' x:num="2500000"> Rp 2,500,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r114'>
      <td height='18' class='x22' style='height:13.5pt;'>6.</td>
      <td class='x44'>Pemberitahuan dan Penyerahan Memori PK</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="175000"> Rp 175,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="250000"> Rp 250,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r115'>
      <td height='18' class='x22' style='height:13.5pt;'>7.</td>
      <td class='x44'>Pemberitahuan Jawaban/Kontra Memori PK</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="175000"> Rp 175,000</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="250000"> Rp 250,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r116'>
      <td height='18' class='x22' style='height:13.5pt;'>8</td>
      <td class='x44'>Pemberitahuan Putusan Penggugat dan Tergugat</td>
      <td class='x23' x:num="200000"> Rp 200,000</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="350000"> Rp 350,000</td>
      <td class='x23' x:num="400000"> Rp 400,000</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="700000"> Rp 700,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.25pt' id='r117'>
      <td height='19' class='x22' style='height:14.25pt;'>9</td>
      <td class='x44'>PNBP Pemberitahuan 7x</td>
      <td class='x23' x:num="70000"> Rp 70,000</td>
      <td class='x23' x:num="70000"> Rp 70,000</td>
      <td class='x23' x:num="70000"> Rp 70,000</td>
      <td class='x23' x:num="70000"> Rp 70,000</td>
      <td class='x23' x:num="70000"> Rp 70,000</td>
      <td class='x23' x:num="70000"> Rp 70,000</td>
    </tr>
    <tr height='26' class='x19' style='mso-height-source:userset;height:19.5pt' id='r118'>
      <td colspan='2' height='22' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:16.5pt;'>JUMLAH</td>
      <td class='x23' x:num="3400000" x:fmla="=SUM(C110:C118)"> Rp 3,400,000</td>
      <td class='x23' x:num="3600000" x:fmla="=SUM(D110:D118)"> Rp 3,600,000</td>
      <td class='x23' x:num="3700000" x:fmla="=SUM(E110:E118)"> Rp 3,700,000</td>
      <td class='x23' x:num="3800000" x:fmla="=SUM(F110:F118)"> Rp 3,800,000</td>
      <td class='x23' x:num="4000000" x:fmla="=SUM(G110:G118)"> Rp 4,000,000</td>
      <td class='x23' x:num="4400000" x:fmla="=SUM(H110:H118)"> Rp 4,400,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r119'>
      <td height='21' class='x27' style='height:15.95pt;'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r120'>
      <td colspan='3' height='21' class='x20' style='mso-ignore:colspan;height:15.95pt;'>Permohonan Sita Jaminan / Pengangkatan Sita Jaminan</td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r121'>
      <td height='19' class='x22' style='height:14.45pt;'>No.</td>
      <td class='x45'>Uraian</td>
      <td class='x45'>Biaya</td>
      <td class='x45'>Biaya</td>
      <td class='x45'>Biaya</td>
      <td class='x45'>Biaya</td>
      <td class='x45'>Biaya</td>
      <td class='x45'>Biaya</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r122'>
      <td height='19' class='x22' style='height:14.45pt;'>1</td>
      <td class='x32'>Redaksi Surat Penetapan</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r123'>
      <td height='19' class='x22' style='height:14.45pt;'>2</td>
      <td class='x32'>Materai Penetapan</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r124'>
      <td height='19' class='x22' style='height:14.45pt;'>3</td>
      <td class='x31'>Fotokopi Berita Acara</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
    </tr>
    <tr height='24' style='mso-height-source:userset;height:18pt' id='r125'>
      <td height='20' class='x22' style='height:15pt;'>4</td>
      <td class='x32'>Transportasi</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1250000"> Rp 1,250,000</td>
      <td class='x23' x:num="1500000"> Rp 1,500,000</td>
      <td class='x23' x:num="1750000"> Rp 1,750,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r126'>
      <td height='18' class='x22' style='height:13.5pt;'>5</td>
      <td class='x32'>Upah Jurusita</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r127'>
      <td height='19' class='x22' style='height:14.45pt;'>6</td>
      <td class='x32'>Biaya 2 Orang Saksi</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r128'>
      <td height='19' class='x22' style='height:14.45pt;'>7</td>
      <td class='x32'>Biaya Pendaftaran PNBP</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r129'>
      <td height='19' class='x22' style='height:14.45pt;'>8</td>
      <td class='x32'>PNBP&nbsp;</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r130'>
      <td colspan='2' height='19' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:14.45pt;'>JUMLAH</td>
      <td class='x25' align='right' x:num="2355000" x:fmla="=SUM(C123:C130)" style='text-align:right;'> Rp 2,355,000</td>
      <td class='x25' align='right' x:num="2605000" x:fmla="=SUM(D123:D130)" style='text-align:right;'> Rp 2,605,000</td>
      <td class='x25' align='right' x:num="2855000" x:fmla="=SUM(E123:E130)" style='text-align:right;'> Rp 2,855,000</td>
      <td class='x25' align='right' x:num="3105000" x:fmla="=SUM(F123:F130)" style='text-align:right;'> Rp 3,105,000</td>
      <td class='x25' align='right' x:num="3355000" x:fmla="=SUM(G123:G130)" style='text-align:right;'> Rp 3,355,000</td>
      <td class='x25' align='right' x:num="3605000" x:fmla="=SUM(H123:H130)" style='text-align:right;'> Rp 3,605,000</td>
    </tr>
    <tr height='24' style='mso-height-source:userset;height:18pt' id='r131'>
      <td height='22' class='x27' style='height:16.5pt;'></td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x21'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='24' style='mso-height-source:userset;height:18pt' id='r132'>
      <td colspan='4' height='22' class='x20' style='mso-ignore:colspan;height:16.5pt;'>Permohonan Sita Eksekusi dan Pengangkatan Sita Eksekusi</td>
      <td class='x27'></td>
      <td class='x27'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r133'>
      <td height='19' class='x22' style='height:14.45pt;'>No.</td>
      <td class='x45'>Uraian</td>
      <td class='x45'>Biaya</td>
      <td class='x45'>Biaya</td>
      <td class='x45'>Biaya</td>
      <td class='x45'>Biaya</td>
      <td class='x45'>Biaya</td>
      <td class='x45'>Biaya</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.25pt' id='r134'>
      <td height='19' class='x22' style='height:14.25pt;'>1</td>
      <td class='x32'>Materai Penetapan</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r135'>
      <td height='19' class='x22' style='height:14.45pt;'>2</td>
      <td class='x32'>Materai Berita Acara</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r136'>
      <td height='19' class='x22' style='height:14.45pt;'>3</td>
      <td class='x31'>Fotokopi Berita Acara (5 Set)</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r137'>
      <td height='19' class='x22' style='height:14.45pt;'>4</td>
      <td class='x32'>Transportasi</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1250000"> Rp 1,250,000</td>
      <td class='x23' x:num="1500000"> Rp 1,500,000</td>
      <td class='x23' x:num="1750000"> Rp 1,750,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r138'>
      <td height='19' class='x22' style='height:14.45pt;'>5</td>
      <td class='x32'>Upah Jurusita</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r139'>
      <td height='19' class='x22' style='height:14.45pt;'>6</td>
      <td class='x32'>Biaya 2 Orang Saksi</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r140'>
      <td height='19' class='x22' style='height:14.45pt;'>7</td>
      <td class='x32'>Biaya Pendaftaran Sita ke BPN</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r141'>
      <td height='19' class='x22' style='height:14.45pt;'>8</td>
      <td class='x32'>PNBP Pendaftaran Permohonan Sita Eksekusi</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.45pt' id='r142'>
      <td height='19' class='x22' style='height:14.45pt;'>9</td>
      <td class='x32'>PNBP Penetapan Sita Eksekusi</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='23' style='mso-height-source:userset;height:17.25pt' id='r143'>
      <td height='19' class='x22' style='height:14.25pt;'>10</td>
      <td class='x32'>PNBP Berita Acara Sita Eksekusi</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='40' style='mso-height-source:userset;height:30pt' id='r144'>
      <td height='36' class='x22' style='height:27pt;'>11</td>
      <td class='x32'>PNBP Penyerahan Salinan Berita Acara Sita Eksekusi (Per Objek)</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r145'>
      <td colspan='2' height='18' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:13.5pt;'>JUMLAH</td>
      <td class='x25' align='right' x:num="2525000" x:fmla="=SUM(C135:C145)" style='text-align:right;'> Rp 2,525,000</td>
      <td class='x25' align='right' x:num="2775000" x:fmla="=SUM(D135:D145)" style='text-align:right;'> Rp 2,775,000</td>
      <td class='x25' align='right' x:num="3025000" x:fmla="=SUM(E135:E145)" style='text-align:right;'> Rp 3,025,000</td>
      <td class='x25' align='right' x:num="3275000" x:fmla="=SUM(F135:F145)" style='text-align:right;'> Rp 3,275,000</td>
      <td class='x25' align='right' x:num="3525000" x:fmla="=SUM(G135:G145)" style='text-align:right;'> Rp 3,525,000</td>
      <td class='x25' align='right' x:num="3775000" x:fmla="=SUM(H135:H145)" style='text-align:right;'> Rp 3,775,000</td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r146'>
      <td height='19' class='x35' style='height:14.25pt;'></td>
      <td class='x35'></td>
      <td class='x46'></td>
      <td class='x39'></td>
      <td class='x39'></td>
      <td class='x39'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='25' style='mso-height-source:userset;height:18.75pt' id='r147'>
      <td colspan='6' height='23' class='x20' style='mso-ignore:colspan;height:17.25pt;'>PERMOHONAN EKSEKUSI PENGOSONGAN / PENYERAHAN ATAS PUTUSAN PENGADILAN</td>
      <td class='x62'></td>
      <td class='x62'></td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r148'>
      <td rowspan='2' height='42' class='x86' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.5pt;'>No.</td>
      <td rowspan='2' height='42' class='x86' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.5pt;'>Uraian</td>
      <td colspan='6' class='x80' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;'>BIAYA</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r149'>
      <td class='x63'>Radius I</td>
      <td class='x63'>Radius II</td>
      <td class='x63'>Radius III</td>
      <td class='x63'>Radius IV</td>
      <td class='x61'>Radius V</td>
      <td class='x61'>Radius VI</td>
    </tr>
    <tr height='22' class='x19' style='mso-height-source:userset;height:16.5pt' id='r150'>
      <td height='18' class='x22' style='height:13.5pt;'>1</td>
      <td class='x30'>Materai Penetapan Teguran</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r151'>
      <td height='18' class='x22' style='height:13.5pt;'>2</td>
      <td class='x30'>PNBP Pendaftaran Permohonan Eksekusi</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r152'>
      <td height='18' class='x22' style='height:13.5pt;'>3</td>
      <td class='x30'>PNBP Penetapan Teguran</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r153'>
      <td height='18' class='x22' style='height:13.5pt;'>4</td>
      <td class='x30'>PNBP Berita Acara Teguran</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r154'>
      <td height='17' class='x22' style='height:12.75pt;'>5</td>
      <td class='x30'>PNBP Relaas Panggilan kepada P dan T</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r155'>
      <td height='18' class='x22' style='height:13.5pt;'>6</td>
      <td class='x30'>Panggilan Teguran P-2x, T-2x</td>
      <td class='x28' x:num="400000"> Rp 400,000</td>
      <td class='x28' x:num="600000"> Rp 600,000</td>
      <td class='x28' x:num="700000"> Rp 700,000</td>
      <td class='x28' x:num="800000"> Rp 800,000</td>
      <td class='x28' x:num="1000000"> Rp 1,000,000</td>
      <td class='x28' x:num="1400000"> Rp 1,400,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r156'>
      <td height='18' class='x22' style='height:13.5pt;'>7</td>
      <td class='x30'>Biaya Proses</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r157'>
      <td height='18' class='x22' style='height:13.5pt;'>8</td>
      <td class='x24'>Materai Penetapan Eksekusi (4 x @ Rp 10.000)</td>
      <td class='x28' x:num="40000"> Rp 40,000</td>
      <td class='x28' x:num="40000"> Rp 40,000</td>
      <td class='x28' x:num="40000"> Rp 40,000</td>
      <td class='x28' x:num="40000"> Rp 40,000</td>
      <td class='x28' x:num="40000"> Rp 40,000</td>
      <td class='x28' x:num="40000"> Rp 40,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r158'>
      <td height='18' class='x22' style='height:13.5pt;'>9</td>
      <td class='x30'>Materai Berita Acara Eksekusi</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r159'>
      <td height='18' class='x22' style='height:13.5pt;'>10</td>
      <td class='x30'>Fotokopi Berita Acara (5 set)</td>
      <td class='x28' x:num="50000"> Rp 50,000</td>
      <td class='x28' x:num="50000"> Rp 50,000</td>
      <td class='x28' x:num="50000"> Rp 50,000</td>
      <td class='x28' x:num="50000"> Rp 50,000</td>
      <td class='x28' x:num="50000"> Rp 50,000</td>
      <td class='x28' x:num="50000"> Rp 50,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r160'>
      <td height='18' class='x22' style='height:13.5pt;'>11</td>
      <td class='x30'>PNBP Penetapan Eksekusi</td>
      <td class='x28' x:num="25000"> Rp 25,000</td>
      <td class='x28' x:num="25000"> Rp 25,000</td>
      <td class='x28' x:num="25000"> Rp 25,000</td>
      <td class='x28' x:num="25000"> Rp 25,000</td>
      <td class='x28' x:num="25000"> Rp 25,000</td>
      <td class='x28' x:num="25000"> Rp 25,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r161'>
      <td height='18' class='x22' style='height:13.5pt;'>12</td>
      <td class='x30'>PNBP Berita Acara Eksekusi</td>
      <td class='x28' x:num="25000"> Rp 25,000</td>
      <td class='x28' x:num="25000"> Rp 25,000</td>
      <td class='x28' x:num="25000"> Rp 25,000</td>
      <td class='x28' x:num="25000"> Rp 25,000</td>
      <td class='x28' x:num="25000"> Rp 25,000</td>
      <td class='x28' x:num="25000"> Rp 25,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r162'>
      <td height='18' class='x22' style='height:13.5pt;'>13</td>
      <td class='x30'>PNBP Penyerahan Salinan Berita Acara Eksekusi</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r163'>
      <td height='18' class='x22' style='height:13.5pt;'>14</td>
      <td class='x30'>Biaya Konstatering</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1250000"> Rp 1,250,000</td>
      <td class='x23' x:num="1500000"> Rp 1,500,000</td>
      <td class='x23' x:num="1750000"> Rp 1,750,000</td>
      <td class='x23' x:num="2000000"> Rp 2,000,000</td>
      <td class='x23' x:num="2500000"> Rp 2,500,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r164'>
      <td height='18' class='x22' style='height:13.5pt;'>15</td>
      <td class='x30'>Biaya Saksi (2 Orang)</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r165'>
      <td height='18' class='x22' style='height:13.5pt;'>16</td>
      <td class='x30'>Rakor Eksekusi (15 orang) dan konsumsi</td>
      <td class='x28' x:num="2500000"> Rp 2,500,000</td>
      <td class='x28' x:num="2500000"> Rp 2,500,000</td>
      <td class='x28' x:num="2500000"> Rp 2,500,000</td>
      <td class='x28' x:num="2500000"> Rp 2,500,000</td>
      <td class='x28' x:num="2500000"> Rp 2,500,000</td>
      <td class='x28' x:num="2500000"> Rp 2,500,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r166'>
      <td height='18' class='x22' style='height:13.5pt;'>17</td>
      <td class='x30'>Biaya penyerahan undangan Rakor</td>
      <td class='x28' x:num="200000"> Rp 200,000</td>
      <td class='x28' x:num="200000"> Rp 200,000</td>
      <td class='x28' x:num="200000"> Rp 200,000</td>
      <td class='x28' x:num="200000"> Rp 200,000</td>
      <td class='x28' x:num="200000"> Rp 200,000</td>
      <td class='x28' x:num="200000"> Rp 200,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r167'>
      <td height='18' class='x22' style='height:13.5pt;'>18</td>
      <td class='x30'>Biaya Pemberitahuan Pelaksanaan Eksekusi</td>
      <td class='x28' x:num="200000"> Rp 200,000</td>
      <td class='x28' x:num="200000"> Rp 200,000</td>
      <td class='x28' x:num="200000"> Rp 200,000</td>
      <td class='x28' x:num="200000"> Rp 200,000</td>
      <td class='x28' x:num="200000"> Rp 200,000</td>
      <td class='x28' x:num="200000"> Rp 200,000</td>
    </tr>
    <tr height='24' style='mso-height-source:userset;height:18pt' id='r168'>
      <td height='20' class='x22' style='height:15pt;'>19</td>
      <td class='x30'>Biaya Pelaksanaan Eksekusi</td>
      <td class='x28' x:num="4500000"> Rp 4,500,000</td>
      <td class='x28' x:num="4500000"> Rp 4,500,000</td>
      <td class='x28' x:num="4500000"> Rp 4,500,000</td>
      <td class='x28' x:num="4500000"> Rp 4,500,000</td>
      <td class='x28' x:num="4500000"> Rp 4,500,000</td>
      <td class='x28' x:num="4500000"> Rp 4,500,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r169'>
      <td colspan='2' height='18' class='x83' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:13.5pt;'>JUMLAH</td>
      <td class='x34' align='right' x:num="10080000" x:fmla="=SUM(C151:C169)" style='text-align:right;'> Rp10,080,000</td>
      <td class='x34' align='right' x:num="10530000" x:fmla="=SUM(D151:D169)" style='text-align:right;'> Rp 10,530,000</td>
      <td class='x34' align='right' x:num="10880000" x:fmla="=SUM(E151:E169)" style='text-align:right;'> Rp 10,880,000</td>
      <td class='x34' align='right' x:num="11230000" x:fmla="=SUM(F151:F169)" style='text-align:right;'> Rp 11,230,000</td>
      <td class='x34' align='right' x:num="11680000" x:fmla="=SUM(G151:G169)" style='text-align:right;'> Rp11,680,000</td>
      <td class='x34' align='right' x:num="12580000" x:fmla="=SUM(H151:H169)" style='text-align:right;'> Rp 12,580,000</td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r170'>
      <td height='19' class='x66' style='height:14.25pt;'></td>
      <td class='x66'></td>
      <td class='x72'></td>
      <td class='x73'></td>
      <td class='x73'></td>
      <td class='x73'></td>
      <td class='x72'></td>
      <td class='x72'></td>
    </tr>
    <tr height='25' style='mso-height-source:userset;height:18.75pt' id='r171'>
      <td colspan='5' height='23' class='x20' style='mso-ignore:colspan;height:17.25pt;'>EKSEKUSI LELANG ATAS PUTUSAN PENGADILAN DAN LELANG HAK TANGGUNGAN</td>
      <td class='x66'></td>
      <td class='x62'></td>
      <td class='x62'></td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r172'>
      <td rowspan='2' height='42' class='x86' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.5pt;'>No.</td>
      <td rowspan='2' height='42' class='x86' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:31.5pt;'>Uraian</td>
      <td colspan='6' class='x83' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;'>BIAYA</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r173'>
      <td class='x63'>Radius 1</td>
      <td class='x63'>Radius II</td>
      <td class='x63'>Radius III</td>
      <td class='x63'>Radius IV</td>
      <td class='x61'>Radius V</td>
      <td class='x61'>Radius VI</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r174'>
      <td height='18' class='x22' style='height:13.5pt;'>1</td>
      <td class='x30'>Materai Penetapan Teguran</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r175'>
      <td height='18' class='x22' style='height:13.5pt;'>2</td>
      <td class='x30'>PNBP Pendaftaran Permohonan Eksekusi</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r176'>
      <td height='18' class='x22' style='height:13.5pt;'>3</td>
      <td class='x30'>PNBP Penetapan Teguran</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r177'>
      <td height='18' class='x22' style='height:13.5pt;'>4</td>
      <td class='x30'>PNBP Berita Acara Teguran</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r178'>
      <td height='18' class='x22' style='height:13.5pt;'>5</td>
      <td class='x30'>PNBP Relaas Panggilan kepada P dan T</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
      <td class='x28' x:num="20000"> Rp 20,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r179'>
      <td height='18' class='x22' style='height:13.5pt;'>6</td>
      <td class='x30'>Panggilan Teguran P-2x, T-2x</td>
      <td class='x28' x:num="400000"> Rp 400,000</td>
      <td class='x28' x:num="600000"> Rp 600,000</td>
      <td class='x28' x:num="700000"> Rp 700,000</td>
      <td class='x28' x:num="800000"> Rp 800,000</td>
      <td class='x28' x:num="1000000"> Rp 1,000,000</td>
      <td class='x28' x:num="1400000"> Rp 1,400,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r180'>
      <td height='18' class='x22' style='height:13.5pt;'>7</td>
      <td class='x30'>Biaya Proses</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
      <td class='x23' x:num="50000"> Rp 50,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r181'>
      <td height='18' class='x22' style='height:13.5pt;'>8</td>
      <td class='x24'>Materai Penetapan Eksekusi (4 x @ Rp 10.000)</td>
      <td class='x23' x:num="40000"> Rp 40,000</td>
      <td class='x23' x:num="40000"> Rp 40,000</td>
      <td class='x23' x:num="40000"> Rp 40,000</td>
      <td class='x23' x:num="40000"> Rp 40,000</td>
      <td class='x23' x:num="40000"> Rp 40,000</td>
      <td class='x23' x:num="40000"> Rp 40,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r182'>
      <td height='18' class='x22' style='height:13.5pt;'>9</td>
      <td class='x24'>Materai Berita Acara Eksekusi Lelang</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
      <td class='x28' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r183'>
      <td height='18' class='x22' style='height:13.5pt;'>10</td>
      <td class='x24'>PNBP Berita Acara Teguran 3x</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
      <td class='x23' x:num="30000"> Rp 30,000</td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r184'>
      <td height='17' class='x22' style='height:12.75pt;'>11</td>
      <td class='x24'>PNBP Penetapan Lelang</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r185'>
      <td height='18' class='x22' style='height:13.5pt;'>12</td>
      <td class='x24'>PNBP Pengumuman Lelang</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r186'>
      <td height='18' class='x22' style='height:13.5pt;'>13</td>
      <td class='x24'>PNBP Pembagian Hasil Lelang</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r187'>
      <td height='18' class='x22' style='height:13.5pt;'>14</td>
      <td class='x24'>Biaya Konstatering</td>
      <td class='x23' x:num="700000"> Rp 700,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1250000"> Rp 1,250,000</td>
      <td class='x23' x:num="1500000"> Rp 1,500,000</td>
      <td class='x23' x:num="1750000"> Rp 1,750,000</td>
      <td class='x23' x:num="2000000"> Rp 2,000,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r188'>
      <td height='18' class='x22' style='height:13.5pt;'>15</td>
      <td class='x24'>Biaya Iklan Surat Kabar (2 x @ Rp 2.700.000)</td>
      <td class='x23' x:num="5400000"> Rp 5,400,000</td>
      <td class='x23' x:num="5400000"> Rp 5,400,000</td>
      <td class='x23' x:num="5400000"> Rp 5,400,000</td>
      <td class='x23' x:num="5400000"> Rp 5,400,000</td>
      <td class='x23' x:num="5400000"> Rp 5,400,000</td>
      <td class='x23' x:num="5400000"> Rp 5,400,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r189'>
      <td height='18' class='x22' style='height:13.5pt;'>16</td>
      <td class='x31'>Transportasi ke kantor Lelang 3x</td>
      <td class='x23' x:num="450000"> Rp 450,000</td>
      <td class='x23' x:num="450000"> Rp 450,000</td>
      <td class='x23' x:num="450000"> Rp 450,000</td>
      <td class='x23' x:num="450000"> Rp 450,000</td>
      <td class='x23' x:num="450000"> Rp 450,000</td>
      <td class='x23' x:num="450000"> Rp 450,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r190'>
      <td height='18' class='x22' style='height:13.5pt;'>17</td>
      <td class='x31' style='overflow:hidden;'>Biaya pemberitahuan Lelang : P, T, Lurah, BPN, KPKNL</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="875000"> Rp 875,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1250000"> Rp 1,250,000</td>
      <td class='x23' x:num="1750000"> Rp 1,750,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r191'>
      <td height='18' class='x22' style='height:13.5pt;'>18</td>
      <td class='x31'>Biaya Pendaftaran Lelang (disetor ke KPKNL)</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r192'>
      <td height='18' class='x22' style='height:13.5pt;'>19</td>
      <td class='x31'>Biaya Pembuatan SKPT</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r193'>
      <td height='18' class='x22' style='height:13.5pt;'>20</td>
      <td class='x31'>Biaya Pelaksanaan Lelang*</td>
      <td class='x23' x:num="2000000"> Rp 2,000,000</td>
      <td class='x23' x:num="2000000"> Rp 2,000,000</td>
      <td class='x23' x:num="2000000"> Rp 2,000,000</td>
      <td class='x23' x:num="2000000"> Rp 2,000,000</td>
      <td class='x23' x:num="2000000"> Rp 2,000,000</td>
      <td class='x23' x:num="2000000"> Rp 2,000,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r194'>
      <td height='18' class='x22' style='height:13.5pt;'>21</td>
      <td class='x31'>PNBP Penetapan Pencabutan Perintah Lelang</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
      <td class='x23' x:num="25000"> Rp 25,000</td>
    </tr>
    <tr height='31' style='mso-height-source:userset;height:23.25pt' id='r195'>
      <td height='27' class='x22' style='height:20.25pt;'>22</td>
      <td class='x31'>PNBP Pengumuman Pencabutan Lelang</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r196'>
      <td colspan='2' height='18' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:13.5pt;'>JUMLAH</td>
      <td class='x25' align='right' x:num="9955000" x:fmla="=SUM(C175:C196)" style='text-align:right;'> Rp 9,955,000</td>
      <td class='x25' align='right' x:num="10705000" x:fmla="=SUM(D175:D196)" style='text-align:right;'> Rp 10,705,000</td>
      <td class='x25' align='right' x:num="11180000" x:fmla="=SUM(E175:E196)" style='text-align:right;'> Rp 11,180,000</td>
      <td class='x25' align='right' x:num="11655000" x:fmla="=SUM(F175:F196)" style='text-align:right;'> Rp 11,655,000</td>
      <td class='x25' align='right' x:num="12355000" x:fmla="=SUM(G175:G196)" style='text-align:right;'> Rp12,355,000</td>
      <td class='x25' align='right' x:num="13505000" x:fmla="=SUM(H175:H196)" style='text-align:right;'> Rp 13,505,000</td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r197'>
      <td height='19' class='x35' style='height:14.25pt;'></td>
      <td class='x35'></td>
      <td class='x46'></td>
      <td class='x39'></td>
      <td class='x39'></td>
      <td class='x39'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='25' style='mso-height-source:userset;height:18.75pt' id='r198'>
      <td colspan='2' height='23' class='x64' style='mso-ignore:colspan;height:17.25pt;'>PEMERIKSAAN SETEMPAT ( PS )</td>
      <td class='x65'></td>
      <td class='x65'></td>
      <td class='x65'></td>
      <td class='x65'></td>
      <td class='x65'></td>
      <td class='x65'></td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r199'>
      <td rowspan='2' height='40' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:30pt;'>No.</td>
      <td rowspan='2' height='40' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:30pt;'>Uraian</td>
      <td colspan='6' class='x83' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;'>Biaya</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r200'>
      <td class='x63'>Radius 1</td>
      <td class='x63'>Radius II</td>
      <td class='x63'>Radius III</td>
      <td class='x63'>Radius IV</td>
      <td class='x61'>Radius V</td>
      <td class='x61'>Radius VI</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r201'>
      <td height='18' class='x22' style='height:13.5pt;'>1</td>
      <td class='x24'>Transportasi PS</td>
      <td class='x23' x:num="500000"> Rp 500,000</td>
      <td class='x23' x:num="750000"> Rp 750,000</td>
      <td class='x23' x:num="1000000"> Rp 1,000,000</td>
      <td class='x23' x:num="1500000"> Rp 1,500,000</td>
      <td class='x23' x:num="1750000"> Rp 1,750,000</td>
      <td class='x23' x:num="2000000"> Rp 2,000,000</td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r202'>
      <td height='18' class='x22' style='height:13.5pt;'>2</td>
      <td class='x24'>Pemberitahuan Kepada Lurah/kepala Desa</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="100000"> Rp 100,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
      <td class='x23' x:num="150000"> Rp 150,000</td>
      <td class='x23' x:num="300000"> Rp 300,000</td>
    </tr>
    <tr height='19' style='mso-height-source:userset;height:14.25pt' id='r203'>
      <td height='15' class='x22' style='height:11.25pt;'>3</td>
      <td class='x24'>PNBP PS</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
      <td class='x23' x:num="10000"> Rp 10,000</td>
    </tr>
    <tr height='19' style='mso-height-source:userset;height:14.25pt' id='r204'>
      <td colspan='2' height='15' class='x22' style='border-right:2px solid windowtext;border-bottom:2px solid windowtext;height:11.25pt;'>JUMLAH</td>
      <td class='x25' align='right' x:num="610000" x:fmla="=SUM(C202:C204)" style='text-align:right;'> Rp 610,000</td>
      <td class='x25' align='right' x:num="860000" x:fmla="=SUM(D202:D204)" style='text-align:right;'> Rp 860,000</td>
      <td class='x25' align='right' x:num="1160000" x:fmla="=SUM(E202:E204)" style='text-align:right;'> Rp 1,160,000</td>
      <td class='x25' align='right' x:num="1810000" x:fmla="=SUM(F202:F204)" style='text-align:right;'> Rp 1,810,000</td>
      <td class='x25' align='right' x:num="1910000" x:fmla="=SUM(G202:G204)" style='text-align:right;'> Rp 1,910,000</td>
      <td class='x25' align='right' x:num="2310000" x:fmla="=SUM(H202:H204)" style='text-align:right;'> Rp 2,310,000</td>
    </tr>
    <tr height='19' style='mso-height-source:userset;height:14.25pt' id='r205'>
      <td height='15' class='x35' style='height:11.25pt;'></td>
      <td class='x35'></td>
      <td class='x46'></td>
      <td class='x46'></td>
      <td class='x46'></td>
      <td class='x46'></td>
      <td class='x46'></td>
      <td class='x46'></td>
    </tr>
    <tr height='20' style='mso-height-source:userset;height:15pt' id='r206'>
      <td colspan='2' height='18' class='x50' style='mso-ignore:colspan;height:13.5pt;'>CATATAN :<br></td>
      <td class='x51'></td>
      <td class='x52'></td>
      <td class='x52'></td>
      <td class='x52'></td>
      <td class='x68'></td>
      <td class='x69'></td>
    </tr>
    <tr height='20' style='mso-height-source:userset;height:15pt' id='r207'>
      <td height='20' class='x53' style='height:15pt;'>1. Biaya-biaya tersebut bisa berubah ditentukan menurut keadaan banyaknya pihak yang berperkara, letak dan jauhnya tempat tinggal pihak yang berperkara</td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x62'></td>
      <td class='x70'></td>
    </tr>
    <tr height='20' style='mso-height-source:userset;height:15pt' id='r208'>
      <td height='20' class='x53' style='height:15pt;'>2. Apabila biaya perkara selama proses berlangsung tersebut habis / kurang untuk tambahan biaya dibebankan kepada pihak Penggugat / Pelawan&nbsp;</td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x62'></td>
      <td class='x70'></td>
    </tr>
    <tr height='22' class='x49' style='mso-height-source:userset;height:16.5pt' id='r209'>
      <td height='22' class='x53' style='height:16.5pt;'>3. Apabila perkara putus ada kelebihan biaya perkara akan dikembalikan kepada pihak Penggugat / Pemohon</td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x67'></td>
      <td class='x71'></td>
    </tr>
    <tr height='22' class='x49' style='mso-height-source:userset;height:16.5pt' id='r210'>
      <td height='22' class='x53' style='height:16.5pt;'>4. Apabila dalam waktu 180 (seratus delapan puluh) hari setelah diberitahukan sisa panjar tidak diambil, akan disetor ke Kas Negara sebagai Pendapatan Negara Bukan Pajak (PNBP)</td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x48'></td>
      <td class='x48'></td>
      <td class='x55'></td>
      <td class='x49'></td>
      <td class='x71'></td>
    </tr>
    <tr height='20' class='x49' style='mso-height-source:userset;height:15pt' id='r211'>
      <td height='20' class='x56' style='height:15pt;'>* Biaya Pelaksanaan Eksekusi terdiri dari: 1. Konsumsi dilapangan (15 orang) Rp. 700.000 2. Honor Petugas Pelaksana Eksekusi Rp. 2.500.000 (Panitera Rp. 500.000,</td>
      <td class='x48'></td>
      <td class='x48'></td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x54'></td>
      <td class='x49'></td>
      <td class='x71'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r212'>
      <td height='21' class='x53' style='height:15.75pt;'><span style='mso-spacerun:yes;'>&nbsp;&nbsp;</span>Tim Eksekusi 5 x @Rp. 300.000, Saksi 2 x @Rp. 250.000) 3. Honor Lurah dll 4 x @Rp.200.000 Rental Mobil<span style='mso-spacerun:yes;'>&nbsp;&nbsp;</span>(transportasi) Rp. 500.000</td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x47'></td>
      <td class='x62'></td>
      <td class='x70'></td>
    </tr>
    <tr height='22' style='mso-height-source:userset;height:16.5pt' id='r213'>
      <td colspan='7' height='20' class='x57' style='mso-ignore:colspan;height:15pt;'>* Biaya pengosongan dan lelang dilihat dari obyek sengketa yang dilelang / tempat lelang dari para pihak serta situasi dan kondisi lapangan.</td>
      <td class='x60'></td>
    </tr>
    <tr height='20' style='mso-height-source:userset;height:15pt' id='r214'>
      <td height='20' class='x16' style='height:15pt'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r215'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td colspan='3' class='x90'>DITETAPKAN DI : TONDANO</td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r216'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td colspan='3' class='x90'>PADA TANGGAL :<span style='mso-spacerun:yes;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>MEI 2023</td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r217'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td colspan='3' class='x90'>WAKIL KETUA PENGADILAN NEGERI TONDANO</td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r218'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td colspan='3' class='x90'>KELAS 1B</td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r219'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x18'></td>
      <td class='x18'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r220'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x18'></td>
      <td class='x18'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r221'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x18'></td>
      <td class='x18'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r222'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td colspan='3' class='x88'>ERENST JANNES ULAEN, SH, M.H</td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r223'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td colspan='3' class='x89'>NIP. 197001281997031001</td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='140' style='mso-height-source:userset;height:105pt;mso-xlrowspan:7' id='r224'>
      <td height='140' class='x16' style='height:105pt'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
      <td class='x16'></td>
    </tr>
    <tr height='24' style='mso-height-source:userset;height:18pt' id='r225'>
      <td height='24' class='x16' style='height:18pt;'></td>
      <td class='x20'></td>
      <td class='x39'></td>
      <td class='x39'></td>
      <td class='x35'></td>
      <td class='x35'></td>
      <td class='x35'></td>
      <td class='x62'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r226'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td rowspan='2' height='42' class='x35' style='height:31.5pt;'></td>
      <td rowspan='2' height='42' class='x35' style='height:31.5pt;'></td>
      <td colspan='6' class='x35'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r227'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x66'></td>
      <td class='x66'></td>
      <td class='x66'></td>
      <td class='x66'></td>
      <td class='x35'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r228'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r229'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r230'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r231'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r232'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r233'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r234'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r235'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x76'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r236'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r237'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r238'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r239'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r240'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r241'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r242'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
      <td class='x36'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r243'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r244'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r245'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r246'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td class='x35'></td>
      <td class='x74'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
      <td class='x75'></td>
    </tr>
    <tr height='21' style='mso-height-source:userset;height:15.75pt' id='r247'>
      <td height='21' class='x16' style='height:15.75pt;'></td>
      <td colspan='2' class='x66'></td>
      <td class='x72'></td>
      <td class='x72'></td>
      <td class='x72'></td>
      <td class='x72'></td>
      <td class='x72'></td>
    </tr>
    <![if supportMisalignedColumns]>
    <tr height='0' style='display:none'>
      <td width='30' style='width:22.5pt'></td>
      <td width='393' style='width:294.75pt'></td>
      <td width='120' style='width:90pt'></td>
      <td width='123' style='width:92.25pt'></td>
      <td width='128' style='width:96pt'></td>
      <td width='124' style='width:93pt'></td>
      <td width='121' style='width:90.75pt'></td>
      <td width='125' style='width:93.75pt'></td>
    </tr>
    <![endif]>
  </table>

  <script language='javascript' type='text/javascript'>
    function ChangeRowspanHiddenData() {
      var node;
      var params = ["r7", "r24", "r38", "r53", "r75", "r91", "r107", "r148", "r172", "r199", "r226"];
      for (var i = 0; i < params.length; i++) {
        node = document.getElementById(params[i]);
        if (node != null) {
          node.style.display = "";
        }
      }
    }
    ChangeRowspanHiddenData();
  </script>
</body>

</html>