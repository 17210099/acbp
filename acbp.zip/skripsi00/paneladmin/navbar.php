<body>
    <li class="sub-menu">
        <a href="javascript:;">
            <i class="fa fa-desktop"></i>
            <span>WILAYAH</span>
        </a>
        <ul class="sub">
            <li><a href="wilayah.php">MINAHASA</a></li>
            <li><a href="tomohon.php">TOMOHON</a></li>
            <li><a href="minahasatenggara.php">MINAHASA TENGGARA</a></li>


        </ul>
    </li>
    <li class="sub-menu">
        <a href="javascript:;">
            <i class="fa fa-desktop"></i>
            <span>GUGATAN</span>
        </a>
        <ul class="sub">
            <li><a href="radius.php">RADIUS</a></li>
            <li><a href="biayaumum.php">BIAYA UMUM</a></li>


        </ul>
    </li>
    <li class="sub-menu">
        <a href="javascript:;">
            <i class="fa fa-desktop"></i>
            <span>PERMOHONAN</span>
        </a>
        <ul class="sub">
            <li><a href="radius2.php">RADIUS</a></li>
            <li><a href="biayaumum2.php">BIAYA UMUM</a></li>


        </ul>
    </li>
    <li class="sub-menu">
        <a href="form.php">
            <i class="fa fa-desktop"></i>
            <span>HITUNG DELEGASI</span>
        </a>
    <li class="sub-menu">
        <a href="javascript:;">
            <i class="fa fa-cogs"></i>
            <span>AKUN</span>
        </a>
        <ul class="sub">
            <li><a href="register.php">TAMBAH AKUN</a></li>

        </ul>
    </li>


    <body>